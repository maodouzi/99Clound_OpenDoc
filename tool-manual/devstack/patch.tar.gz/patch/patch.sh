#! /bin/sh

TOP_DIR=$(cd $(dirname "$0") && pwd)
DEV_STACK_DIR=${TOP_DIR}/..

IDENTITY_CODE="nEvErMaTcHeD"

if [ ! -f ${DEV_STACK_DIR}/stack.sh ];then
	echo "Error! DEV_STACK_DIR=${DEV_STACK_DIR}, couldn't find stack.sh!"
	exit
fi

#localrc
cp ${TOP_DIR}/etc/localrc ${DEV_STACK_DIR}

#prepare patch stack.sh
cp ${DEV_STACK_DIR}/stack.sh ${DEV_STACK_DIR}/re-stack.sh
sed -i "/${IDENTITY_CODE}/d" ${DEV_STACK_DIR}/re-stack.sh

#patch: add patch.sh
sed -i "s/^source \$TOP_DIR\/functions/source \$TOP_DIR\/functions\\nsource \$TOP_DIR\/patch\/libs\/patch_functions.sh #${IDENTITY_CODE}/" ${DEV_STACK_DIR}/re-stack.sh
sed -i "s/^source \$TOP_DIR\/lib\/database/source \$TOP_DIR\/lib\/database\\nsource \$TOP_DIR\/patch\/libs\/patch_functions.sh #${IDENTITY_CODE}/" ${DEV_STACK_DIR}/re-stack.sh
sed -i "s/^source \$TOP_DIR\/lib\/tempest/source \$TOP_DIR\/lib\/tempest\\nsource \$TOP_DIR\/patch\/libs\/patch_modules.sh #${IDENTITY_CODE}/" ${DEV_STACK_DIR}/re-stack.sh

#patch: remove keystone-data.sh
sed -i "s/bash -x \$FILES\/keystone_data.sh/echo 'bash -x keystone_data.sh'/" ${DEV_STACK_DIR}/re-stack.sh

#patch: remove nova-manage
sed -i "s/\$NOVA_BIN_DIR\/nova-manage/echo 'nova-manage' #${IDENTITY_CODE}\\n#\$NOVA_BIN_DIR\/nova-manage/" ${DEV_STACK_DIR}/re-stack.sh
sed -i "s/#echo 'nova-manage'/echo 'nova-manage'/" ${DEV_STACK_DIR}/re-stack.sh

#patch for keystone.conf
if [ ! -f ${DEV_STACK_DIR}/lib/keystone.org ];then
	cp ${DEV_STACK_DIR}/lib/keystone ${DEV_STACK_DIR}/lib/keystone.org
fi
cp ${DEV_STACK_DIR}/lib/keystone.org ${DEV_STACK_DIR}/lib/keystone
sed -i "s/iniset \$KEYSTONE_CONF DEFAULT admin_token \"\$SERVICE_TOKEN\"/iniset \$KEYSTONE_CONF DEFAULT admin_token \"\$SERVICE_TOKEN\"\niniset \$KEYSTONE_CONF DEFAULT log_file \"keystone.log\"\niniset \$KEYSTONE_CONF DEFAULT log_dir \"\/opt\/stack\/keystone\/\"\niniset \$KEYSTONE_CONF token driver \"keystone.token.backends.sql.Token\"/" ${DEV_STACK_DIR}/lib/keystone
sed -i "s/KEYSTONE_TOKEN_FORMAT:-PKI/KEYSTONE_TOKEN_FORMAT:-UUID/" ${DEV_STACK_DIR}/lib/keystone
