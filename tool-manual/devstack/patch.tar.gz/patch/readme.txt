First Time Patch Steps:
1. copy patch dir under devstack dir, use sync2vm.sh, example: ./sync2vm.sh 192.168.122.102
2. cd to vm patch dir
3. run ./patch.sh
4. run ./stack.sh to create devstack enviroment
5. run ./config.sh
6. cd to vm devstack dir
7. run ./unstack.sh to stop openstack
8. run ./re-stack.sh to restart openstack

Other Times, Just Launch Exist DevStack Environment
1. cd to vm devstack dir
2. run ./re-stack.sh to launch openstack

BugList:
*1. Couldn't remove upload_image funciton in functions, if remove, image couldn't startup.
	Actually, not bug, just vm instance named "test" duplicated.
2. Quamtum localrc startup, vm instance could run active, but couldn't be connected. 
