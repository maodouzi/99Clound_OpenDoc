#! /bin/sh

TOP_DIR=$(cd $(dirname "$0") && pwd)
DEV_STACK_DIR=${TOP_DIR}/..

IDENTITY_CODE="nEvErMaTcHeD"

if [ ! -f ${DEV_STACK_DIR}/stack.sh ];then
	echo "Error! DEV_STACK_DIR=${DEV_STACK_DIR}, couldn't find stack.sh!"
	exit
fi
