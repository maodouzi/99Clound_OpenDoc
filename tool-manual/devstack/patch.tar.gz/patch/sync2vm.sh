#! /bin/sh

if [ $# -ne 1 ];then
	echo "$0 <remote_ipaddr>" 
	exit
fi

REMOTE_IP=$1
USERNAME=pear
PATCH_DIR=/home/${USERNAME}/devstack/patch/

ssh ${USERNAME}@${REMOTE_IP} "mkdir -p ${PATCH_DIR};rm -rf {PATCH_DIR}/*"
scp -r ./* ${USERNAME}@${REMOTE_IP}:/${PATCH_DIR}
