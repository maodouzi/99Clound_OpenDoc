function configure_keystone() {
	echo "configure_keystone $*"
}

function init_keystone() {
	echo "init_keystone $*"
}

function start_keystone() {
    screen_it key "cd $KEYSTONE_DIR && $KEYSTONE_DIR/bin/keystone-all --config-file $KEYSTONE_CONF -d --debug -v"
}

function cleanup_keystone() {
	echo "clean_keystone $*"
}

function configure_glance() {
    echo "configure_glance $*"
}

function init_glance() {
    echo "init_glance $*"
}

function cleanup_glance() {
    echo "cleanup_glance$*"
}

function configure_cinder() {
    echo "configure_cinder $*"
}

function init_cinder() {
    echo "init_cinder $*"
}

function cleanup_cinder() {
    echo "cleanup_cinder $*"
}

function configure_nova() {
    echo "configure_nova $*"
}

function init_nova() {
    echo "init_nova $*"
}

function cleanup_nova() {
    echo "cleanup_nova $*"
}


