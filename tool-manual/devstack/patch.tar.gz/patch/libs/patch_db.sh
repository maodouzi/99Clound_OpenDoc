function recreate_database {
	echo "recreate_database $*"
}

function install_database {
	echo "install_database $*"
}

function configure_database {
    echo "configure_database $*"
}

