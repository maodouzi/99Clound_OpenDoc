function git_clone {
	echo "git_clone $*"  
}

function install_package() {
	echo "install_package $*"
}

function pip_install {
	echo "pip_install $*"
}

function setup_develop() {
	echo "setup_develop $*"
}

function upload_image() {
	echo "upload_image $*"
}

NO_UPDATE_REPOS=True
